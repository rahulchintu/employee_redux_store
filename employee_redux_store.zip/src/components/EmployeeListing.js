import React, { useEffect, useCallback, useMemo } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setEmployees } from "../Redux/actions/employee_action";
import EmployeeComponent from "./EmployeeComponent";
import {Header} from "./header";
 const EmployeePage = () =>{
    const employees = useSelector((state) => state.employees);
    const dispatch = useDispatch();
    const fetchEmployees = async () => {
      const response = await axios
        .get("https://my-json-server.typicode.com/rahulchintu/testing/employees")
        .catch((err) => {
          console.log("Err: ", err);
        });
      dispatch(setEmployees(response.data));
    };

  useEffect(() => {
   fetchEmployees();
  }, [])

  console.log("employees :", employees);
  if(employees){
  return <>
  <Header />
  <EmployeeComponent />
   </>
  }
  return <> </>
}
export default EmployeePage;
import React from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { DeleteOutlined } from '@ant-design/icons';
import './EmployeeList.css';
import { editEmployee, removeEmployee } from "../Redux/actions/employee_action";
const EmployeeComponent = () => {
  const employees = useSelector((state) => state.employees);
  const dispatch = useDispatch();
  console.log("helloemployees",employees)
  
    return (
      <div>
          <div style={{float:'left',margin:'20px'}}>
              <button className="btn btn-secondary">Add Employee</button>
          </div>
        <table className="table table-striped">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">FirstName</th>
              <th scope="col">LastName</th>
              <th scope="col">address</th>
              <th scope="col">salary</th>
              <th scope="col">DOB</th>
              <th scope="col">Edit</th>
              <th scope="col">Delete</th>
            </tr>
          </thead>
          <tbody>
              {employees.map((employee) =>
              <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{employee.FirstName}</td>
              <td>{employee.LastName}</td>
              <td>{employee.address}</td>
              <td>{employee.salary}</td>
              <td>{employee.DOB}</td>
              <td className="editIcon text-center" onClick={() =>{ dispatch(editEmployee([employee]))}}></td>
              <td style={{cursor:'pointer'}} onClick={() => dispatch(removeEmployee(employee))}><DeleteOutlined /></td>
            </tr>
              )}
            
          </tbody>
        </table>
      </div>
    );
 
  
};
export default EmployeeComponent;

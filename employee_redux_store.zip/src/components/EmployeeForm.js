import { useState } from "react";
import {useForm} from 'react-hook-form';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
const schema = yup.object(
    {
    
        firstName:yup.string().required().min(3),
        lastName:yup.string().required().min(3),
        address:yup.string().required(),
        salary:yup.number().positive().integer().required(),
        dob:yup.date().required(),
    }
)


const EmployeeForm = () => {
   

    const {register,handleSubmit,errors} = useForm({
        resolver: yupResolver(schema),
    });

    const submitForm = (data) =>{
        console.log(data)
    }


  return (
    <form onSubmit={handleSubmit(submitForm)}>
      <div className="form-group">
        <label>FirstName</label>
        <input type="text"  name="firstName" className="form-control" ref={register()} />
        <label>LastName</label>
        <input type="text"  name="lastName" className="form-control" ref={register()}/>
        <label>address</label>
        <input type="text"   name="address" className="form-control" ref={register()}/>
        <label>salary</label>
        <input type="number" name="salary" className="form-control" ref={register()} />
        <label>DOB</label>
        <input type="date" name="dob" className="form-control" />
        <input type="submit" className="btn btn-secondary"/>
      </div>
    </form>
  );
};
export default EmployeeForm;

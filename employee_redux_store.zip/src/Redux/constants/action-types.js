export const ActionTypes = {
    Add_Employee : 'Add_Employee',
    Edit_Employee : 'Edit_Employee',
    Remove_Employee:'Remove_Employee'
}



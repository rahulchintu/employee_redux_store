import {ActionTypes} from '../constants/action-types';

export const setEmployees = (employees) => {
    return{
        type: ActionTypes.Add_Employee,
        payload: employees,
    }
}

export const editEmployee = (employee) => {

    return{
        type : ActionTypes.Edit_Employee,
        payload:employee
    }
}
export const removeEmployee  = (employee) => {
    
    return{
        type:ActionTypes.Remove_Employee,
        payload:employee
    }
}
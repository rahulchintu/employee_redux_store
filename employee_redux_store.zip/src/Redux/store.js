import {createStore} from 'redux';
import  {employee_reducer} from './reducers/employee_reducer';
import { applyMiddleware } from 'redux';
import ThunkMiddleware from 'redux-thunk';

// const store = createStore(employee_reducer,applyMiddleware(ThunkMiddleware),
//     window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
//     );



const store = createStore(employee_reducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())

export default store;


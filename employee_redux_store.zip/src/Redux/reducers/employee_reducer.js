
import {ActionTypes} from '../constants/action-types';

const initial_state = {
    employees : []
}
export const employee_reducer = (state= initial_state,{type,payload}) => {
    
    switch (type) {
        case ActionTypes.Add_Employee:
            return {...state,employees:payload};
            
        case ActionTypes.Edit_Employee:
            alert("edit employee sucessful")
            
            return {
                ...state,employees:payload
                   
            };
            
        case ActionTypes.Remove_Employee:
            alert("remove employee succesful")
            let employeesfilter = state.employees.filter(employee => {
               return employee.id != payload.id;
            })
            console.log(employeesfilter)
            return {
                
                ...state, employees:employeesfilter
            };
    
        default:
            return state;
    }
}
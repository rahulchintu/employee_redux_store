import EmployeePage from './components/EmployeeListing';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import EmployeeForm from './components/EmployeeForm'

function App() {
  return (
    <div className="App">
      <EmployeePage />
      <EmployeeForm />
    </div>
  );
}

export default App;
